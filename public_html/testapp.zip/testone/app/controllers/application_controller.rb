class ApplicationController < ActionController::Base
before_filter :get_website
  protect_from_forgery
end
