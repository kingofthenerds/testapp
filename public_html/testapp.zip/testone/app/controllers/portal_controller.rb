class PortalController < ApplicationController


end
