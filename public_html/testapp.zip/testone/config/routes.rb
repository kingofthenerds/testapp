Testone::Application.routes.draw do
  root :to => "portal#show_page"
end
